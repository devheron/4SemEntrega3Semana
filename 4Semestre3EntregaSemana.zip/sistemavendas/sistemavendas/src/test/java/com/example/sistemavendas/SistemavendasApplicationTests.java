package com.example.sistemavendas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemavendasApplicationTests {

	@Test
	void contextLoads() {
	}

}
